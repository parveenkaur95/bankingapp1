﻿using System;
using BankBEntities;
using BankClasslib;
using System.Collections.Generic;

namespace BankConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            List<CAccountsEnt> listobj = new List<CAccountsEnt>();
            CAccountsEnt[] accentobj = new CAccountsEnt[1]; //creating object array of accountent
            for (int counter = 0; counter < accentobj.Length; counter++)
            {
                accentobj[counter] = new CAccountsEnt();
            }
            for (int counter = 0; counter < accentobj.Length; counter++)
            {
                 Console.WriteLine("Enter Account No.");
                 accentobj[counter].ACCOUNTNO = Convert.ToInt32(Console.ReadLine());
                 Console.WriteLine("Enter Account Holder Name");
                 accentobj[counter].ACC_HOLD_NAME = Console.ReadLine();
                 Console.WriteLine("Enter Account Type");
                 accentobj[counter].ACC_TYPE= Console.ReadLine();
                 Console.WriteLine("Enter Transaction Type");
                 accentobj[counter].TRANS_TYPE =Console.ReadLine();
                 Console.WriteLine("Enter Amount");
                 accentobj[counter].AMOUNT = Convert.ToDecimal(Console.ReadLine());
            }

            listobj.AddRange(accentobj);
            foreach (var item in listobj)
            {
                Console.WriteLine("Account No is {0}", item.ACCOUNTNO);
                Console.WriteLine("Account Name is {0}", item.ACC_HOLD_NAME);
                Console.WriteLine("Account Type is {0}", item.ACC_TYPE);
                Console.WriteLine("Transaction Type is {0}", item.TRANS_TYPE);
                Console.WriteLine("Amount is {0}", item.AMOUNT);
              //  Console.WriteLine("Your Balance is {0}", item.BALANCE);

            }
            //CAccountsEnt entobj = new CAccountsEnt();
           CSavingAccounts accobj = new CSavingAccounts(accentobj[0]);
           Console.WriteLine(accobj.BALANCE);
            accentobj[0].AMOUNT = 5000;
            try
            {
                accobj.mWithdraw(accentobj[0]);
            }

            catch (InSufficientFundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

           // accobj.mWithdraw(accentobj[0]);
          Console.WriteLine(accobj.BALANCE);
        }
    }
}
