﻿using System;
using BankBEntities;

namespace BankClasslib
{
    public abstract class CAccounts
    {
        #region Field
        //private decimal _balance;
        #endregion

        #region Property

        //public decimal BALANCE { get { return _balance; } }
        #endregion


        #region Method

        public abstract void mDeposit(CAccountsEnt accobj);

        public abstract void mWithdraw(CAccountsEnt accobj);
        #endregion



        #region Constructor
        #endregion

      

    }
}
