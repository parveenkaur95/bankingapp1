﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankClasslib
{
    interface ICalcInterest
    {
        decimal interestcalc(int time, float rate, decimal amt);
    }
}
