﻿using System;
using BankBEntities;

namespace BankClasslib
{
   public class CSavingAccounts:CAccounts, ICalcInterest
    {
        #region Field
        private decimal _balance;

        #endregion

        #region Property

        public decimal BALANCE { get { return _balance; } }
        #endregion

        #region Method

        public override void mDeposit(BankBEntities.CAccountsEnt accobj)
        {
            _balance += accobj.AMOUNT;
        }

        public override void mWithdraw(BankBEntities.CAccountsEnt accobj)
        {
            if (_balance > 5000)
            {
                _balance -= accobj.AMOUNT;
            }
            else
            {
                throw new InSufficientFundException("You have insufficient amount in your account");
            }
        }

        public decimal interestcalc(int time, float rate, decimal amt)
        {
            return ((decimal)time * (decimal) rate * amt);
        }
        #endregion

        #region Constructor

        public CSavingAccounts()
        {
           
        }
        public CSavingAccounts(CAccountsEnt entobj)
        {
            _balance = entobj.AMOUNT;
        }
        #endregion
        
    }
}
