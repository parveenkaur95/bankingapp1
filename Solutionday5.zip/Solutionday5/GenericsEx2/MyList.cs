﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsEx2
{
    public class MyList<T>
    {

        static List<T> listobj = new List<T>();

        public static void Add(T obj)
        {
            listobj.Add(obj);
           // listobj.Add(obj1);
        }

    }
}
