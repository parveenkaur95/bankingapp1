﻿using System;
using System.Collections;


//namespace ArrayListEx
//{
   // public class ArrayList
   // {

       // public static void Main()
       // {
          //  ArrayList myAL = new ArrayList();
         //  myAL.Add("One");
          // myAL.Add("Two");
          // myAL.Add("!");
          // myAL.Add(20);
        //   Console.WriteLine("\tCount:{0}, myAL.Count);
        //   Console.WriteLine("\tCount:{0}, myAL.Capacity);
           //    Console.Write("\tValues:");
           // foreach (var item in PrintValues(myAL))
           // {
           //     Console.WriteLine(item.ToString());
           // }
            //  Console.Read();
       //}
       // public static IEnumerable PrintValues(ArrayList myList);
      ///  foreach(ValueType item in myList)
   // {
     //   yield return item;
  //  }

   //{
   //  IEnumerable myEnumerator= mylist.Get
    //}
//}
