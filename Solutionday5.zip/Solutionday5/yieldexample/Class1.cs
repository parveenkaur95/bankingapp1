﻿using System;
using System.Collections;


namespace yieldexample
{
    public class Class1
    {

        public static IEnumerable Power(int number, int exponent)
        {
            int result = 1;
            int counter = 0;
            while (counter++ < exponent)
            {
                result = result * number;
                yield return result;

            }
        }
     

            public static void main()
            {
                foreach (int i in Power(2,8))
                {
                    Console.Write("{0}",i);
                }
            
            }
             
        }
    }

