﻿using System;

namespace DelegateEx
{
    delegate T calculate<T>(T num1, T num2);
    class DelegateExclass
    {

        public static int add(int mynum1, int mynum2)
        {
            Console.WriteLine(mynum1 + mynum2);
            return mynum1 + mynum2;
        }

        public static int subtract(int mynum1, int mynum2)
        {
            Console.WriteLine(mynum1 - mynum2);
            return mynum1 - mynum2;
        }
        public static int multiply(int mynum1, int mynum2)
        {
            Console.WriteLine(mynum1 * mynum2);
            return mynum1 * mynum2;
        }

        public static float divide(float mynum1, float mynum2)
        {
            Console.WriteLine((float)mynum1 / mynum2);
            return (float)mynum1 / mynum2;
        }

        static void Main(String[] args)
        {
            calculate<int> calcobj = new calculate<int>(add);
            calculate<float> calcobj1 = new calculate<float>(divide);
            calcobj += new calculate<int>(subtract);
            calcobj += new calculate<int>(multiply);
            Console.WriteLine(calcobj.Invoke(10, 20));
            calcobj -= new calculate<int>(multiply);
            calcobj -= new calculate<int>(multiply);
            Console.WriteLine(calcobj1(20.0f,10.0f));
            Console.WriteLine(calcobj.Invoke(30, 20));


            // Console.WriteLine(calcobj(10,20));
        }
    }
}
